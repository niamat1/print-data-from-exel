import xlrd
def totalSellary():
    f_loc = "nn.xls"
    wb = xlrd.open_workbook(f_loc)
    fp = wb.sheet_by_index(0)
    i=0
    row = 0
    total =0
    while(i<6):
        name = fp.cell_value(row,0)
        sl = fp.cell_value(row,1)
        print(name,"\t=\t",int(sl),"\tTK")
        total = int(total + sl)
        row+=1
        i+=1
    print("total\t=\t",total,"\tTK")
totalSellary()